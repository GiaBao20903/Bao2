﻿namespace HuynhGiaBao_22118978_Assigment1
{
    partial class FormDesign
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_Xanh = new System.Windows.Forms.Panel();
            this.panel_Do = new System.Windows.Forms.Panel();
            this.panel_Vang = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.but_BD = new System.Windows.Forms.Button();
            this.but_KT = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button_OnX = new System.Windows.Forms.Button();
            this.button_OnD = new System.Windows.Forms.Button();
            this.button_OnV = new System.Windows.Forms.Button();
            this.button_OffX = new System.Windows.Forms.Button();
            this.button_OffD = new System.Windows.Forms.Button();
            this.button_OffV = new System.Windows.Forms.Button();
            this.panel_Xanh.SuspendLayout();
            this.panel_Do.SuspendLayout();
            this.panel_Vang.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_Xanh
            // 
            this.panel_Xanh.BackColor = System.Drawing.Color.Lime;
            this.panel_Xanh.Controls.Add(this.label1);
            this.panel_Xanh.Location = new System.Drawing.Point(3, 3);
            this.panel_Xanh.Name = "panel_Xanh";
            this.panel_Xanh.Size = new System.Drawing.Size(136, 132);
            this.panel_Xanh.TabIndex = 0;
            // 
            // panel_Do
            // 
            this.panel_Do.BackColor = System.Drawing.Color.Red;
            this.panel_Do.Controls.Add(this.label2);
            this.panel_Do.Location = new System.Drawing.Point(3, 159);
            this.panel_Do.Name = "panel_Do";
            this.panel_Do.Size = new System.Drawing.Size(136, 132);
            this.panel_Do.TabIndex = 1;
            // 
            // panel_Vang
            // 
            this.panel_Vang.BackColor = System.Drawing.Color.Yellow;
            this.panel_Vang.Controls.Add(this.label3);
            this.panel_Vang.Location = new System.Drawing.Point(3, 318);
            this.panel_Vang.Name = "panel_Vang";
            this.panel_Vang.Size = new System.Drawing.Size(136, 132);
            this.panel_Vang.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Xanh";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(24, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Đỏ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1, 15);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 16);
            this.label3.TabIndex = 3;
            this.label3.Text = "Vàng";
            // 
            // but_BD
            // 
            this.but_BD.BackColor = System.Drawing.SystemColors.Info;
            this.but_BD.ForeColor = System.Drawing.Color.Lime;
            this.but_BD.Location = new System.Drawing.Point(441, 12);
            this.but_BD.Name = "but_BD";
            this.but_BD.Size = new System.Drawing.Size(130, 91);
            this.but_BD.TabIndex = 4;
            this.but_BD.Text = "Bắt Đầu";
            this.but_BD.UseVisualStyleBackColor = false;
            // 
            // but_KT
            // 
            this.but_KT.BackColor = System.Drawing.SystemColors.Info;
            this.but_KT.ForeColor = System.Drawing.Color.Red;
            this.but_KT.Location = new System.Drawing.Point(642, 12);
            this.but_KT.Name = "but_KT";
            this.but_KT.Size = new System.Drawing.Size(130, 91);
            this.but_KT.TabIndex = 5;
            this.but_KT.Text = "Kết Thúc";
            this.but_KT.UseVisualStyleBackColor = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.button_OffV);
            this.panel1.Controls.Add(this.button_OnX);
            this.panel1.Controls.Add(this.button_OffD);
            this.panel1.Controls.Add(this.button_OnV);
            this.panel1.Controls.Add(this.button_OnD);
            this.panel1.Controls.Add(this.button_OffX);
            this.panel1.Controls.Add(this.panel_Xanh);
            this.panel1.Controls.Add(this.panel_Do);
            this.panel1.Controls.Add(this.panel_Vang);
            this.panel1.Location = new System.Drawing.Point(442, 116);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(330, 468);
            this.panel1.TabIndex = 6;
            // 
            // button_OnX
            // 
            this.button_OnX.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.button_OnX.ForeColor = System.Drawing.Color.Lime;
            this.button_OnX.Location = new System.Drawing.Point(168, 42);
            this.button_OnX.Name = "button_OnX";
            this.button_OnX.Size = new System.Drawing.Size(58, 63);
            this.button_OnX.TabIndex = 2;
            this.button_OnX.Text = "ON";
            this.button_OnX.UseVisualStyleBackColor = false;
            this.button_OnX.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // button_OnD
            // 
            this.button_OnD.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.button_OnD.ForeColor = System.Drawing.Color.Lime;
            this.button_OnD.Location = new System.Drawing.Point(168, 190);
            this.button_OnD.Name = "button_OnD";
            this.button_OnD.Size = new System.Drawing.Size(58, 63);
            this.button_OnD.TabIndex = 3;
            this.button_OnD.Text = "ON";
            this.button_OnD.UseVisualStyleBackColor = false;
            // 
            // button_OnV
            // 
            this.button_OnV.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.button_OnV.ForeColor = System.Drawing.Color.Lime;
            this.button_OnV.Location = new System.Drawing.Point(168, 352);
            this.button_OnV.Name = "button_OnV";
            this.button_OnV.Size = new System.Drawing.Size(58, 63);
            this.button_OnV.TabIndex = 4;
            this.button_OnV.Text = "ON";
            this.button_OnV.UseVisualStyleBackColor = false;
            // 
            // button_OffX
            // 
            this.button_OffX.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.button_OffX.ForeColor = System.Drawing.Color.Red;
            this.button_OffX.Location = new System.Drawing.Point(251, 42);
            this.button_OffX.Name = "button_OffX";
            this.button_OffX.Size = new System.Drawing.Size(58, 63);
            this.button_OffX.TabIndex = 5;
            this.button_OffX.Text = "OFF";
            this.button_OffX.UseVisualStyleBackColor = false;
            // 
            // button_OffD
            // 
            this.button_OffD.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.button_OffD.ForeColor = System.Drawing.Color.Red;
            this.button_OffD.Location = new System.Drawing.Point(251, 190);
            this.button_OffD.Name = "button_OffD";
            this.button_OffD.Size = new System.Drawing.Size(58, 63);
            this.button_OffD.TabIndex = 6;
            this.button_OffD.Text = "OFF";
            this.button_OffD.UseVisualStyleBackColor = false;
            // 
            // button_OffV
            // 
            this.button_OffV.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.button_OffV.ForeColor = System.Drawing.Color.Red;
            this.button_OffV.Location = new System.Drawing.Point(251, 352);
            this.button_OffV.Name = "button_OffV";
            this.button_OffV.Size = new System.Drawing.Size(58, 63);
            this.button_OffV.TabIndex = 4;
            this.button_OffV.Text = "OFF";
            this.button_OffV.UseVisualStyleBackColor = false;
            // 
            // FormDesign
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(1293, 597);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.but_KT);
            this.Controls.Add(this.but_BD);
            this.Name = "FormDesign";
            this.Text = "Base1";
            this.panel_Xanh.ResumeLayout(false);
            this.panel_Xanh.PerformLayout();
            this.panel_Do.ResumeLayout(false);
            this.panel_Do.PerformLayout();
            this.panel_Vang.ResumeLayout(false);
            this.panel_Vang.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_Xanh;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel_Do;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel_Vang;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button but_BD;
        private System.Windows.Forms.Button but_KT;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button_OnX;
        private System.Windows.Forms.Button button_OffV;
        private System.Windows.Forms.Button button_OffD;
        private System.Windows.Forms.Button button_OffX;
        private System.Windows.Forms.Button button_OnV;
        private System.Windows.Forms.Button button_OnD;
    }
}

